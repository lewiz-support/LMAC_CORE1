
Nov 20, 2018

LeWiz Communications, Inc.

Although the documents may contain information about LEWIZ LMAC CORE1, CORE2, and CORE3
This release is only intended for LMAC CORE1 (1G/100M/10M) only.
CORE2 and CORE3 are for potential future releases and users should not rely on 
CORE2 and CORE3 information.