
Copy and put the "TESTS\Rx_TESTS" folder from LMAC_INFO_part2 zip file to here
Copy and put the "TESTS\Tx_TESTS" folder from LMAC_INFO_part3 zip file to here
