
This part3 contain a portion of the LMAC_INFO release.
Copy "TESTS\Tx_TESTS" folder and put in \LMAC_INFO\TESTS
